def create_character_card(name, description):
    return {"name": name, "description": description}

def list_character_cards():
    return []