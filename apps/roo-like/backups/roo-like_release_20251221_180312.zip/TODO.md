﻿# TODO (roo-like)
- [ ] Define scope
- [ ] Add minimal smoke test
