#!/usr/bin/env python3

def main():
    print("Hello from roo-like app!")

if __name__ == "__main__":
    main()