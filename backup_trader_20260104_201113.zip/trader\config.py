import os
from pathlib import Path

# プロジェクトのパス
BASE_DIR = Path(r"C:\Users\FHiro\Projects\ai-agents\trader")

# データ・ログ・モデルの保存先
DATA_DIR = Path(r"D:\ai-data\trader\data")
LOG_DIR = Path(r"D:\ai-data\trader\logs")
MODELS_DIR = Path(r"D:\ai-data\trader\models")

INITIAL_CAPITAL = 10_000  # 最初の資金（円）
FEE_RATE = 0.0005         # 手数料率の仮値

# データ更新開始日（既存データがない場合）
START_DATE = "2017-08-17"  # Binance BTCUSDT 取引開始日

# 銘柄設定（後方互換のためSYMBOLを維持）
SYMBOL = os.getenv('TRADER_SYMBOL', 'BTCUSDT')  # デフォルト銘柄
TRADER_SYMBOLS = os.getenv('TRADER_SYMBOLS', '')
SYMBOLS = [s.strip() for s in TRADER_SYMBOLS.split(',') if s.strip()] if TRADER_SYMBOLS else [SYMBOL]

# リスク設定
RISK_CONFIG = {
    "risk_per_trade_pct": 0.5  # 初期値
}

# フォルダが無ければ作る
for p in [DATA_DIR, LOG_DIR, MODELS_DIR]:
    p.mkdir(parents=True, exist_ok=True)
