﻿============================= test session starts =============================
platform win32 -- Python 3.10.6, pytest-9.0.2, pluggy-1.6.0
rootdir: C:\Users\FHiro\Projects\ai-agents
configfile: pytest.ini
plugins: anyio-3.7.1
collected 9 items / 2 errors

=================================== ERRORS ====================================
______________________ ERROR collecting test_all_log.txt ______________________
..\..\AppData\Local\Programs\Python\Python310\lib\pathlib.py:1135: in read_text
    return f.read()
..\..\AppData\Local\Programs\Python\Python310\lib\codecs.py:322: in decode
    (result, consumed) = self._buffer_decode(data, self.errors, final)
E   UnicodeDecodeError: 'utf-8' codec can't decode byte 0xff in position 0: invalid start byte
_________________ ERROR collecting test_voice_changer_log.txt _________________
..\..\AppData\Local\Programs\Python\Python310\lib\pathlib.py:1135: in read_text
    return f.read()
..\..\AppData\Local\Programs\Python\Python310\lib\codecs.py:322: in decode
    (result, consumed) = self._buffer_decode(data, self.errors, final)
E   UnicodeDecodeError: 'utf-8' codec can't decode byte 0xff in position 0: invalid start byte
=========================== short test summary info ===========================
ERROR test_all_log.txt - UnicodeDecodeError: 'utf-8' codec can't decode byte ...
ERROR test_voice_changer_log.txt - UnicodeDecodeError: 'utf-8' codec can't de...
!!!!!!!!!!!!!!!!!!! Interrupted: 2 errors during collection !!!!!!!!!!!!!!!!!!!
============================== 2 errors in 1.25s ==============================
